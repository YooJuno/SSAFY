#include <iostream>
#include <algorithm>

using namespace std;

int map[101][101];

int calcSum(int n, int k, int y, int x)
{
	int sum = 0;

	for (int i = max(0, (y - k)); i <= min(n - 1, y + k); i++)
	{
		for (int j = max(0, x - k); j <= min(n - 1, x + k); j++)
		{
			if ((i == y || x == j || abs(i - y) == abs(j - x)) && (x != j || y != i))
			{
				sum += map[i][j];
			}
		}
	}


	return sum;
}

int main()
{
	int N; cin >> N; // 0 <= N <= 100000s

	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			cin >> map[i][j];

	int K; cin >> K;

	int maxSum = 0;

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			int result = calcSum(N, K, i, j);
			if (result > maxSum)
				maxSum = result;
		}
	}

	cout << maxSum;

	return 0;
}

