#include <iostream>
#include <algorithm>
using namespace std;

int weight[22];

int recursive(int depth, int weightSum, int w, int k, int b)
{
	if (weightSum + w > k)
	{
		return weightSum;
	}

	if (depth == b) return weightSum + w;

	return max(recursive(depth + 1, weightSum + w, weight[depth], k, b),
		recursive(depth + 1, weightSum + w, 0, k, b));
}

int main()
{
	int K; cin >> K; // 10 <= K <= 35000
	int B; cin >> B; // 1 <= B <= 21

	for (int i = 0; i < B; i++)
		cin >> weight[i];

	cout << recursive(0, 0, 0, K, B) << endl;

	return 0;
}

