#include <iostream>
#include <algorithm>

using namespace std;


int main()
{
	int N; cin >> N;
	int sample[101];
	long long int arr[202];
	int minDif = 10001;
	long long int maxSum = 0;
	int cnt = 0;
	for (int i = 0; i < N; i++)
	{
		cin >> sample[i];
		for (int j = 0; j < i; j++)
		{
			arr[cnt++] = sample[i] * sample[j];
		}
	}


	for (int i = 0; i < cnt - 1; i++)
	{
		for (int j = i + 1; j < cnt; j++)
		{
			if (minDif == abs(arr[i] - arr[j]))
			{
				if (maxSum < arr[i] + arr[j])
				{
					maxSum = arr[i] + arr[j];
				}
			}
			else if (minDif > abs(arr[i] - arr[j]))
			{
				minDif = abs(arr[i] - arr[j]);
				maxSum = arr[i] + arr[j];
			}
		}
	}

	cout << maxSum << endl;

	return 0;
}

